package main

import "fmt"

func main() {
	ang := 60 * 3.14 / 180
	fmt.Println(cordic(int(ang * 1024)))
}

func cordic(t_angle int) int {

	// parameter nr_iterat= 12; // number of iterations (max 13)
	nr_iterat := 12
	FXP_SCALE := 1024

	t_cos := int(0.5 * float64(FXP_SCALE))

	arctan := []int{804, 475, 251, 127, 64, 32, 16, 8, 4, 2, 1, 0}
	Kn := []int{1024, 724, 648, 628, 623, 622, 622, 622, 622, 622, 622, 622}
	cos := 1 * FXP_SCALE //Initial vector x coordinate
	sin := 0 * FXP_SCALE //and y coordinate
	angle := 0
	angle_deg := 0

	// integer i;
	var tmp int
	// initial begin //Execute only once
	for i := 0; i < nr_iterat; i = i + 1 {
		if t_angle > angle {
			angle = angle + arctan[i]
			tmp = cos - (sin >> i)
			sin = (cos >> i) + sin
			cos = tmp
		} else {
			angle = angle - arctan[i]
			tmp = cos + (sin >> i)
			sin = -(cos >> i) + sin
			cos = tmp
		}
		sin_out := (sin * Kn[i]) >> 10
		cos_out := (cos * Kn[i]) >> 10

		// $display("i=%02d, angle=%f [deg], sin=%f, cos=%f, cos_error=%f",
		//  i, angle_deg, sin_out,cos_out, (cos_out-t_cos));
		angle_deg = angle * 180 / 3215
		fFXP_SCALE := float32(FXP_SCALE)
		fmt.Printf("i=%02d, angle=%f [deg], sin=%f, cos=%f, cos_error=%d\n", i, float32(angle_deg), float32(sin_out)/fFXP_SCALE, float32(cos_out)/fFXP_SCALE, (cos_out - t_cos))
	}

	return 0
}
